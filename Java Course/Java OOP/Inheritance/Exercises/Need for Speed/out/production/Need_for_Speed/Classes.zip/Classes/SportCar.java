package Classes;

public class SportCar extends Car{
    public SportCar(double fuel, int horsePower){
        super(fuel, horsePower);
        this.setDEFAULT_FUEL_CONSUMPTION(10);
    }
}
