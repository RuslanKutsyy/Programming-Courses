package Person;

public class Person {
    private String Name;
    private Integer Age;

    public Person(String name, Integer age){
        this.Name = name;
        this.Age = age;
    }

    public String getName(){
        return this.Name;
    }

    public Integer getAge(){
        return this.Age;
    }
}