package Person;

public class Child extends Person{
    public Child(String name, Integer age){
        super(name, age);
    }
}
