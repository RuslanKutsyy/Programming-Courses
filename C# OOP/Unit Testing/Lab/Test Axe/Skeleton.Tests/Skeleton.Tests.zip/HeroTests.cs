﻿using NUnit.Framework;

[TestFixture]
public class HeroTests
{
    [Test]
    public void Test1()
    {

    }
}