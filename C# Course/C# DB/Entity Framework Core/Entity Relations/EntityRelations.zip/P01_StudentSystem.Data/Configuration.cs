﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_StudentSystem.Data
{
    public static class Configuration
    {
        public const string ConnectionString = "Server=SQLSRV;Database=StudentSystem;User ID=RemoteAdmin;Password=P@ssword1;";
    }
}
