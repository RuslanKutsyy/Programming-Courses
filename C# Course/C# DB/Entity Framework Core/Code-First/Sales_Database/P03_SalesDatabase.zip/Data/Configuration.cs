﻿namespace P03_SalesDatabase.Data
{
    public static class Configuration
    {
        public const string ConnectionString =
            "Server=SQLSRV;Database=Sales;User ID=RemoteAdmin;Password=P@ssword1;";
    }
}
