﻿namespace VaporStore.Data
{
	public static class Configuration
	{
		public static string ConnectionString =
			@"Server=SQLSRV;Database=VaporStore;User ID=RemoteAdmin; Password=P@ssword1;";
	}
}