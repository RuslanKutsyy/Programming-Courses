﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Border_Control
{
    public interface IMammal
    {
        string Name { get; set; }
        string BirthdayDate { get; set; }
    }
}
