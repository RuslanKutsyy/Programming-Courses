﻿namespace Military_Elite.Emums
{
    public enum State
    {
        inProgress = 1,
        Finished = 2
    }
}