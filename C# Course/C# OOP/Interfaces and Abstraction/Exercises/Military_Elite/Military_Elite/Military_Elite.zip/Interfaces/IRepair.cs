﻿namespace Military_Elite.Interfaces
{
    public interface IRepair
    {
        string PartName { get; }
        int WorkedHours { get; }
    }
}
