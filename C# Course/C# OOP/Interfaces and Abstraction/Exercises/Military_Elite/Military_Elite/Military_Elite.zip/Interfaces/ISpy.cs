﻿namespace Military_Elite.Interfaces
{
    public interface ISpy
    {
        int CodeNumber { get; }
    }
}
